"""
Debug script — traces exactly what split_respecting_code_blocks does to the real
kube-controller-manager.md Options section, to find why the 10572-char chunk persists
even after the recursive _expand_oversized_blocks fix.

Usage:
    uv run python ingestion/debug_chunk.py
"""

import sys
from pathlib import Path

sys.path.insert(0, "ingestion")
from chunk_docs import (  # noqa: E402
    clean_hugo_shortcodes,
    extract_front_matter,
    split_by_headings,
    split_respecting_code_blocks,
    _expand_oversized_blocks,
    MAX_CHUNK_CHARS,
)

FILEPATH = Path(
    "data/raw/website/content/en/docs/reference/command-line-tools-reference/kube-controller-manager.md"
)

raw_text = FILEPATH.read_text(encoding="utf-8", errors="ignore")
meta, body = extract_front_matter(raw_text)
body = clean_hugo_shortcodes(body)

sections = split_by_headings(body)
options_section = next((s for s in sections if s[1].strip().lower() == "options"), None)

if options_section is None:
    print("Could not find an 'Options' section — heading names found:")
    for _, heading, _ in sections:
        print(" -", repr(heading))
    sys.exit(1)

_, heading, content = options_section
print(f"Options section content length: {len(content)} chars")
print(f"Number of '\\n\\n' (double newline) breaks in content: {content.count(chr(10)+chr(10))}")
print(f"Number of '\\n' (single newline) breaks in content: {content.count(chr(10))}")

# Step 1: what does the initial text.split("\n\n") produce?
initial_paragraphs = content.split("\n\n")
print(f"\ntext.split('\\n\\n') produces {len(initial_paragraphs)} paragraph(s)")
for i, p in enumerate(initial_paragraphs):
    print(f"  paragraph[{i}] length: {len(p)}")

# Step 2: what does _expand_oversized_blocks do to it?
expanded = _expand_oversized_blocks(initial_paragraphs, MAX_CHUNK_CHARS)
print(f"\n_expand_oversized_blocks produces {len(expanded)} fragment(s)")
lengths = [len(p) for p in expanded]
print(f"  max fragment length: {max(lengths)}")
print(f"  fragments over {MAX_CHUNK_CHARS} chars: {sum(1 for l in lengths if l > MAX_CHUNK_CHARS)}")

# Find and print the largest fragment, to see exactly what's in it
biggest = max(expanded, key=len)
print(f"\nLargest fragment ({len(biggest)} chars) — first 300 chars:")
print(biggest[:300])
print("...")
print("last 200 chars:")
print(biggest[-200:])

# Step 3: what does the full split_respecting_code_blocks give us?
pieces = split_respecting_code_blocks(content, MAX_CHUNK_CHARS)
print(f"\nsplit_respecting_code_blocks produces {len(pieces)} final piece(s)")
piece_lengths = [len(p) for p in pieces]
print(f"  max piece length: {max(piece_lengths)}")
print(f"  min piece length: {min(piece_lengths)}")

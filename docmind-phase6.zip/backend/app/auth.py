"""
Phase 6 auth — hand-rolled rather than a hosted auth provider, deliberately: the mechanics
here (hash a password, never store it in plaintext; issue a signed token the client presents
on every subsequent request; verify that signature server-side without needing a database
lookup on every single request) are foundational backend patterns worth understanding
directly, not hiding behind a managed service.
"""

from datetime import datetime, timedelta, timezone

import jwt
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from passlib.context import CryptContext
from sqlalchemy.orm import Session

from .config import settings
from .db import get_db
from .models_db import User

# bcrypt: a deliberately slow hashing algorithm (unlike, say, plain SHA-256) — the slowness
# is the point, since it makes brute-forcing stolen password hashes far more expensive. Never
# store a raw or reversibly-encrypted password; only ever store this one-way hash.
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# Tells FastAPI's OpenAPI docs where to send username/password to get a token — also used
# to extract the "Authorization: Bearer <token>" header from incoming requests automatically.
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/login")


def hash_password(password: str) -> str:
    return pwd_context.hash(password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    return pwd_context.verify(plain_password, hashed_password)


def create_access_token(user_id: str) -> str:
    """
    A JWT is a signed (not encrypted) blob — anyone can read its contents, but only someone
    holding jwt_secret_key can have PRODUCED a validly-signed one. That's what lets the server
    trust a token's claims (here, just the user id) without a database round-trip on every
    request: verifying the signature is enough to know the token wasn't forged or tampered
    with, as long as the secret never leaks.
    """
    expire = datetime.now(timezone.utc) + timedelta(minutes=settings.jwt_expire_minutes)
    payload = {"sub": user_id, "exp": expire}
    return jwt.encode(payload, settings.jwt_secret_key, algorithm=settings.jwt_algorithm)


def get_current_user(
    token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)
) -> User:
    """
    FastAPI dependency — add `current_user: User = Depends(get_current_user)` to any route
    that should require authentication. Raises 401 for a missing, malformed, expired, or
    forged token, or one referencing a user that no longer exists.
    """
    credentials_error = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(
            token, settings.jwt_secret_key, algorithms=[settings.jwt_algorithm]
        )
        user_id = payload.get("sub")
        if user_id is None:
            raise credentials_error
    except jwt.PyJWTError:
        raise credentials_error

    user = db.get(User, user_id)
    if user is None:
        raise credentials_error
    return user

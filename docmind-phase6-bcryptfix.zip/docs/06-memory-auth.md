# Phase 6 — Memory & Auth

**Status:** written, pending verification on real hardware (this sandbox has no network
access, so `passlib`/`pyjwt` couldn't be installed to test auth logic in isolation — same
constraint hit with `langgraph` in Phase 5)
**Date:** <!-- fill in -->

## Goal

Turn DocMind from a stateless single-shot Q&A endpoint into a real multi-user chat product:
persistent conversations, follow-up questions that resolve pronouns/references from earlier
turns, and per-user accounts so conversations don't leak between users.

## Why auth and memory are really one feature

"Whose conversation is this?" and "who is this user?" are the same question asked two ways.
You can't build per-user chat history without first knowing who the user is — so this phase
builds both together rather than as separate concerns.

## Deviation from the original plan: hand-rolled JWT auth, not Supabase

The original 9-phase plan named Supabase ("Postgres + Auth in one, fast to set up"). Built
it differently here, deliberately: Supabase Auth is a hosted third-party service, and every
other piece of infrastructure in this project runs locally in your own Docker Compose
(Qdrant, Redis, Postgres, Ollama) — introducing an external SaaS dependency for just this one
piece would break that consistency. More importantly, hand-rolling JWT auth (password
hashing, token issuance, protecting endpoints) teaches the actual mechanics directly, which
matters more for the backend-engineering skills this project is meant to build than wiring
up a managed service that hides them. The local Postgres container from Phase 0 had been
sitting completely unused until now — this phase finally uses it.

## Schema: three tables, minimal by design

```
users            id, email, hashed_password, created_at
conversations    id, user_id (FK), title, created_at
messages         id, conversation_id (FK), role, content, sources (JSON), created_at
```

- One conversation belongs to exactly one user — no shared/team conversations yet (would
  need a join table; deliberately out of scope).
- `messages.sources` is a JSON column storing the citations for assistant messages, so
  reloading history can still show what a past answer cited, not just its raw text.
- **No Alembic migrations yet.** `Base.metadata.create_all()` at startup creates missing
  tables but never alters existing ones — fine while the schema is small and still settling,
  not fine once there's real data and a schema change. Alembic is the right next step once
  that point is reached, not before.

## Auth mechanics — what's actually happening, not just which libraries are used

**Password hashing (bcrypt via passlib):** never store a password in plaintext or even
reversibly encrypted — only a one-way hash. bcrypt is deliberately *slow* (unlike, say, plain
SHA-256) — that slowness is the actual security property, since it makes brute-forcing a
stolen hash database far more computationally expensive.

**JWT (JSON Web Token):** a signed, not encrypted, blob. Anyone can decode and read a JWT's
contents — but only someone holding `jwt_secret_key` could have produced one with a *valid
signature*. That's what lets `get_current_user` trust a token's claims (just the user id
here) without a database round-trip on every single request: verifying the signature is
enough to know the token wasn't forged, as long as the secret key never leaks. This is also
exactly why `JWT_SECRET_KEY`'s dev default is explicitly marked insecure — anyone who knows
that default value could forge a valid token for any user id.

**`get_current_user` as a FastAPI dependency:** adding `current_user: User =
Depends(get_current_user)` to any route is what makes it "protected" — no decorator, no
middleware, just a dependency that raises 401 before the route body ever runs if the token
is missing, malformed, expired, or forged.

## Memory mechanics — how a follow-up question actually gets resolved

1. `/query` now accepts an optional `conversation_id`. Omit it to start a new conversation;
   include it to continue one.
2. **Ownership is checked, not assumed** — a `conversation_id` belonging to a different user
   is rejected with 404, not silently allowed. Without this check, any authenticated user
   could read anyone else's conversation just by guessing or reusing an id.
3. `_load_history` pulls the last `conversation_history_turns` messages (6 = 3 user/assistant
   pairs — enough to resolve most follow-ups without bloating every prompt with the entire
   conversation).
4. History flows into the agent graph's state, then into `build_prompt`, which prepends a
   `CONVERSATION SO FAR:` block before the sources.
5. **Both turns get persisted after generation** — the user's question and the assistant's
   answer (with its citations) both become new `Message` rows, so the *next* call to this
   conversation sees this turn as history too.

## A deliberate anti-hallucination safeguard specific to multi-turn memory

The prompt explicitly instructs: *"Use the conversation so far... only to understand what
the user is referring to — never as a source of facts about Kubernetes itself."* Without this
line, a subtle compounding failure becomes possible: if the model said something slightly
wrong in an earlier turn, a naive prompt might let it treat its own earlier (possibly wrong)
statement as an established fact in the current turn, compounding the error across a
conversation instead of staying anchored to the actual retrieved sources every single time.

## Real bug found: passlib + modern bcrypt incompatibility

First real run hit `ValueError: password cannot be longer than 72 bytes` on
`hash_password("testpass123")` — an 11-character password nowhere near the 72-byte limit,
which was the tell that this wasn't actually about password length. Root cause: `passlib`
(last released in 2020, effectively unmaintained) runs an internal self-test against its
bcrypt backend on first use, and that self-test itself breaks against modern versions of the
`bcrypt` package (>=4.1) — the crash happens inside passlib's own test vector construction,
not on the real input, which is why the error message was so misleading.

**Fixed** by dropping `passlib` and calling `bcrypt` directly — a thinner, actively
maintained dependency, and arguably a better learning outcome anyway: `hash_password` and
`verify_password` now show exactly what's happening (encode to bytes, hash with a random
salt, compare with constant-time comparison) rather than going through an abstraction layer
that turned out to be broken. The 72-byte limit is still real (it's a genuine bcrypt
algorithm constraint, not a passlib artifact) — now enforced explicitly with a clear error
instead of silently truncating, since silent truncation would mean two different passwords
past the limit could hash identically without either user ever being told why.

## How to run

```bash
docker compose -f docker/docker-compose.yml up -d   # Postgres included
uv sync                                              # picks up passlib, pyjwt, email-validator, python-multipart
uv run uvicorn backend.app.main:app --reload
```

Register, then log in (note: `/auth/login` takes form-encoded data, not JSON — see the
`login()` docstring for why):

```bash
curl -X POST http://localhost:8000/auth/register \
  -H "Content-Type: application/json" \
  -d '{"email": "test@example.com", "password": "testpass123"}'

curl -X POST http://localhost:8000/auth/login \
  -d "username=test@example.com&password=testpass123"
```

Use the returned `access_token` for `/query`:

```bash
curl -X POST http://localhost:8000/query \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{"query": "how do I create a Pod?"}'
```

Then send a follow-up in the **same conversation** (using the `conversation_id` from the
first response) and check whether the answer correctly resolves the implicit reference:

```bash
curl -X POST http://localhost:8000/query \
  -H "Authorization: Bearer <token>" \
  -H "Content-Type: application/json" \
  -d '{"query": "what about a DaemonSet instead?", "conversation_id": "<id from above>"}'
```

## Results

<!-- Fill in after running -->

```
Register: succeeded? ___
Login: token received? ___
Query without token: correctly rejected with 401? ___
Query with token, no conversation_id: new conversation created? ___
Follow-up in same conversation: did it correctly resolve "instead of what"? ___
Query with someone else's conversation_id: correctly rejected with 404? ___
```

## Known limitations / things to revisit

- No Alembic migrations — fine now, will need addressing before any real schema change
  after real user data exists.
- No password reset / email verification flow — acceptable for a portfolio project, would
  be required for anything with real users.
- `classify_node` and `direct_node` in the agent don't currently receive conversation
  history, only `retrieve_and_generate_node` does — a greeting like "thanks" doesn't need
  history, but a vague follow-up classified as `clarify` arguably could use it to ask a more
  targeted clarifying question. Noted, not built, to keep this phase's scope bounded.
- Redis (originally planned for "session-level fast access") wasn't introduced in this
  phase — Postgres alone is sufficient at this project's scale, and adding a cache layer
  before there's a measured latency problem would be solving a problem that doesn't exist
  yet. Revisit if `_load_history`'s query time ever actually shows up as a bottleneck.

## Deliverable

- [x] `backend/app/db.py` — SQLAlchemy engine, session, FastAPI dependency
- [x] `backend/app/models_db.py` — User, Conversation, Message ORM models
- [x] `backend/app/auth.py` — password hashing, JWT issuance/verification, `get_current_user`
- [x] `backend/app/main.py` — `/auth/register`, `/auth/login`, `/query` now protected +
      persists history + loads prior turns for follow-up resolution
- [x] `backend/app/llm.py` — `build_prompt` accepts conversation history
- [x] `backend/app/agent.py` — history threaded through agent state
- [ ] Full run on real hardware: register, login, protected query, follow-up resolution,
      cross-user conversation access correctly rejected
- [ ] Results filled in above

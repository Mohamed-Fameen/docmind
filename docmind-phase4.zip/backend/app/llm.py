"""
LLM generation: builds a grounded prompt from retrieved chunks, then calls either Ollama
(dev, local, free) or a hosted API (prod), based on settings.env.

The prompt design is the actual anti-hallucination mechanism here — retrieval alone doesn't
stop an LLM from making things up if the prompt doesn't explicitly forbid it.
"""

from .config import settings


def build_prompt(query: str, chunks: list[dict]) -> tuple[str, list[dict]]:
    """
    Returns (prompt, source_refs). source_refs maps citation numbers to the metadata a
    frontend would need to render a clickable source link (Phase 7).
    """
    context_blocks = []
    source_refs = []
    for i, chunk in enumerate(chunks, start=1):
        context_blocks.append(f"[{i}] {chunk['heading_path']}\n{chunk['text']}")
        source_refs.append(
            {
                "number": i,
                "heading_path": chunk["heading_path"],
                "doc_url": chunk["doc_url"],
            }
        )

    context = "\n\n".join(context_blocks)

    prompt = f"""You are a Kubernetes documentation assistant. Answer the user's question \
using ONLY the information in the sources below. Cite sources inline using their number in \
brackets, like [1]. If the sources don't contain enough information to answer, say so \
directly rather than guessing or using outside knowledge.

SOURCES:
{context}

QUESTION: {query}

ANSWER:"""

    return prompt, source_refs


def _generate_with_ollama(prompt: str) -> str:
    import ollama

    response = ollama.chat(
        model=settings.ollama_model,
        messages=[{"role": "user", "content": prompt}],
    )
    return response["message"]["content"]


def _generate_with_anthropic(prompt: str) -> str:
    import anthropic

    client = anthropic.Anthropic(api_key=settings.anthropic_api_key)
    response = client.messages.create(
        model=settings.anthropic_model,
        max_tokens=1024,
        messages=[{"role": "user", "content": prompt}],
    )
    return "".join(block.text for block in response.content if block.type == "text")


def generate_answer(prompt: str) -> str:
    if settings.env == "prod":
        if not settings.anthropic_api_key:
            raise RuntimeError(
                "ENV=prod but ANTHROPIC_API_KEY is not set. Set it in .env, or switch "
                "ENV=dev to use local Ollama instead."
            )
        return _generate_with_anthropic(prompt)
    return _generate_with_ollama(prompt)

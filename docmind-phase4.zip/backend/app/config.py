"""
Centralized settings, loaded from environment variables (.env in dev).

Kept as a plain class rather than adding pydantic-settings as a new dependency — this
project already uses pydantic for request/response models, but full settings management
is overkill for the handful of values we need here.
"""

import os

from dotenv import load_dotenv

load_dotenv()


class Settings:
    env: str = os.environ.get("ENV", "dev")

    # Qdrant
    qdrant_host: str = os.environ.get("QDRANT_HOST", "localhost")
    qdrant_port: int = int(os.environ.get("QDRANT_PORT", "6333"))
    qdrant_collection: str = os.environ.get("QDRANT_COLLECTION", "k8s_docs")

    # Embeddings / reranking — same embedding model used at index time (Phase 3) MUST be
    # used at query time too, since a bi-encoder's query and passage vectors only compare
    # meaningfully if they came from the same model.
    embedding_model: str = os.environ.get("EMBEDDING_MODEL", "BAAI/bge-base-en-v1.5")
    reranker_model: str = os.environ.get("RERANKER_MODEL", "BAAI/bge-reranker-base")

    # Ollama (dev-time generation)
    ollama_model: str = os.environ.get("OLLAMA_MODEL", "llama3.1:8b")
    ollama_host: str = os.environ.get("OLLAMA_HOST", "http://localhost:11434")

    # Hosted LLM (prod-time generation) — check https://docs.claude.com for current model
    # names before deploying; this default may not reflect the latest available model.
    anthropic_api_key: str | None = os.environ.get("ANTHROPIC_API_KEY") or None
    anthropic_model: str = os.environ.get("ANTHROPIC_MODEL", "claude-haiku-4-5-20251001")

    # Retrieval tuning
    dense_top_n: int = 20   # candidates pulled from vector search before fusion
    bm25_top_n: int = 20    # candidates pulled from keyword search before fusion
    fused_top_n: int = 10   # candidates kept after RRF fusion, before reranking
    final_top_k: int = 5    # chunks actually sent to the LLM after reranking


settings = Settings()

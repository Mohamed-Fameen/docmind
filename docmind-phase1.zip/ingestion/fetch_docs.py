"""
Phase 1 — Data Acquisition

Clones the kubernetes/website repo (the actual source of kubernetes.io) and reports
basic corpus stats: file count, total size, directory breakdown.

We only need the English docs tree (content/en/docs/) — the repo also contains
translations into ~10 other languages, which we don't need and which would bloat
the corpus for no benefit.

Usage:
    uv run python ingestion/fetch_docs.py
"""

import subprocess
import sys
from pathlib import Path

REPO_URL = "https://github.com/kubernetes/website.git"
CLONE_DIR = Path("data/raw/website")
DOCS_SUBPATH = "content/en/docs"


def clone_repo():
    if CLONE_DIR.exists():
        print(f"{CLONE_DIR} already exists — skipping clone.")
        print("  (delete this directory first if you want a fresh clone)")
        return

    print(f"Cloning {REPO_URL} (shallow, depth=1) into {CLONE_DIR} ...")
    CLONE_DIR.parent.mkdir(parents=True, exist_ok=True)

    # Shallow clone — we don't need git history, and the full repo (with all
    # language translations + history) is large. This also means no sparse
    # checkout complexity: still pulls all languages, but much faster than a
    # full clone. Sparse-checkout is an option if you want ONLY content/en/docs
    # on disk (see note below).
    result = subprocess.run(
        ["git", "clone", "--depth", "1", REPO_URL, str(CLONE_DIR)],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        print("Clone failed:", result.stderr, file=sys.stderr)
        sys.exit(1)
    print("Clone complete.")


def report_stats():
    docs_dir = CLONE_DIR / DOCS_SUBPATH
    if not docs_dir.exists():
        print(f"Expected docs directory not found at {docs_dir}")
        print("The kubernetes/website repo structure may have changed — check manually with:")
        print(f"  ls {CLONE_DIR}")
        return

    md_files = list(docs_dir.rglob("*.md"))
    total_bytes = sum(f.stat().st_size for f in md_files)

    # Breakdown by top-level subdirectory (concepts/, tasks/, tutorials/, reference/, etc.)
    subdirs: dict[str, int] = {}
    for f in md_files:
        rel = f.relative_to(docs_dir)
        top = rel.parts[0] if len(rel.parts) > 1 else "(root)"
        subdirs[top] = subdirs.get(top, 0) + 1

    print("\n--- Corpus stats ---")
    print(f"Docs directory:      {docs_dir}")
    print(f"Markdown files:      {len(md_files)}")
    print(f"Total size:          {total_bytes / (1024*1024):.1f} MB")
    print(f"Approx total tokens: {total_bytes // 4:,}  (rough estimate, ~4 bytes/token)")
    print("\nBreakdown by section:")
    for section, count in sorted(subdirs.items(), key=lambda x: -x[1]):
        print(f"  {section:30s} {count:5d} files")


if __name__ == "__main__":
    clone_repo()
    report_stats()

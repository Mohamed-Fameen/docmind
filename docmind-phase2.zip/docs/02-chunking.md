# Phase 2 — Loading & Chunking

**Status:** script written and tested against representative samples of both document shapes
**Date:** <!-- fill in -->

## Goal

Turn raw Kubernetes markdown into retrieval-ready chunks that respect document structure,
rather than blindly splitting on a fixed character count — and handle the fact that this
corpus contains two structurally different kinds of document (see Phase 1 finding).

## The two document shapes

Phase 1 revealed `reference/` is 70% of the corpus (1163 of 1672 files) and is mostly
**auto-generated CLI reference docs** (`content_type: tool-reference`, `auto_generated: true`),
structurally distinct from the prose in `concepts/`/`tasks/`/`tutorials/`:

| | Prose docs (concepts/, tasks/) | Auto-gen reference (reference/generated/) |
|---|---|---|
| Headings | Plain markdown (`## Using Pods`) | Hugo shortcodes (`## {{% heading "options" %}}`) |
| Flags/fields | N/A | Raw HTML `<table>` elements |
| Typical section length | Several paragraphs | Often one line (a single flag) |
| Callouts | `{{< caution >}}...{{< /caution >}}` | Rare |

Both need Hugo shortcode cleanup; only the reference docs need HTML table parsing.

## Approach

`ingestion/chunk_docs.py` runs every file through a shared pipeline, with a preprocessing
step that normalizes both shapes into plain markdown before the same heading/code-aware
splitter handles both:

1. **Strip HTML comments** — the auto-gen boilerplate notice ("This file is auto-generated
   from Go source...") on every reference page, and stray editorial comments elsewhere.
2. **Convert HTML option/field tables → readable bullets.** Tables alternate a flag-name row
   (`<td colspan="2">--cache-dir string ... Default: "..."`) with a description row. Parsed via
   BeautifulSoup into `` - `--cache-dir string` (default: "..."): Default cache directory ``
   — readable prose the embedding model can actually use, instead of raw HTML tags.
3. **Convert Hugo heading shortcodes → markdown headings.** `{{% heading "options" %}}` →
   `Options` (mapped via a small dict: synopsis/examples/options/parentoptions/seealso →
   human-readable titles; anything unrecognized falls back to title-casing the raw name).
   Important subtlety: the `## ` marker is already present in the source line — the
   replacement must produce only the title text, not `## Title` again, or headings double up
   (`## ## Synopsis`). Caught this during testing.
4. **Unwrap callout shortcodes.** `{{< caution >}}...{{< /caution >}}` → `**Caution:** ...`,
   preserving the semantic meaning without leaking template syntax into embeddings.
5. **Drop unresolvable inline shortcodes.** `{{< skew currentVersion >}}` resolves to a version
   number at site-build time, which we don't have here. Rather than guess or hardcode a
   version that will go stale, it's dropped, with a regex cleanup pass afterward to fix the
   orphaned punctuation this leaves behind (`"version , only"` → `"version, only"`).
6. **Split by heading, then by code-fence-respecting paragraph chunks**, same as before —
   this part was unchanged from the original prose-only design and still applies to both
   shapes now that step 2–5 have normalized everything to plain markdown.

## Design decision: excluding "Inherited Options"

The `parentoptions` table (global kubectl flags: `--kubeconfig`, `--namespace`, `--token`,
etc.) is **identical boilerplate on every single kubectl/kubeadm/kubelet reference page** —
100+ pages. Chunking and embedding this same block once per page would:
- waste embedding compute on near-duplicate content, and
- pollute the vector store with hundreds of near-identical vectors that could crowd out
  genuinely distinct results for unrelated queries.

`SKIP_INHERITED_OPTIONS = True` (top of `chunk_docs.py`) drops these sections entirely.
Flip to `False` if you decide later you want per-page global-flag lookup to work too — but
the better fix, if it turns out to matter, is probably a single canonical "kubectl global
flags" chunk rather than re-including it hundreds of times.

## Chunk size decision

- **Prose docs:** `MIN_CHUNK_CHARS = 100`, target `MAX_CHUNK_CHARS = 1200` (~300 tokens) —
  unchanged reasoning from the original design: small enough to stay topically focused, large
  enough to keep a code example with its explanation.
- **Auto-generated reference docs:** `MIN_CHUNK_CHARS_AUTO_GEN = 20`. This was a bug caught
  during testing — applying the 100-char prose minimum to reference docs silently dropped
  **the entire test file** (Synopsis, Examples, Options, See Also were all under 100 chars
  individually). A single flag description (`` `-h, --help`: help for use-context ``, ~35
  chars) is short but complete and exactly what a targeted query should retrieve — it must
  not be filtered out just because it's brief.

## Verified output (from `reference/generated/kubectl/kubectl_config_use-context.md`)

```
Synopsis   → "Set the current-context in a kubeconfig file. ```kubectl config use-context CONTEXT_NAME```"
Examples   → "```# Use the context for the minikube cluster\nkubectl config use-context minikube```"
Options    → "- `-h, --help`: help for use-context"
See Also   → "* [kubectl config](../) - Modify kubeconfig files"
```
(Inherited Options correctly excluded — 4 chunks from this page, not 5.)

And from a prose page with callout + inline shortcodes:
```
"**Caution:** Browsing untrusted pod or service endpoints through `kubectl proxy` is
dangerous, as the served content has implicit access to the Kubernetes API using the
proxy's credentials."

"In Kubernetes version, only the status subresource is supported."
```

## Metadata added

Beyond the original `chunk_id`, `source_file`, `heading_path`, `doc_url`, `k8s_version`:
- `content_type` — from front matter (`concept`, `task`, `tool-reference`, etc.) — lets you
  filter or weight retrieval by document type later if eval shows it helps.
- `auto_generated` (bool) — flags reference-doc chunks distinctly, useful for debugging
  retrieval quality issues specific to one document shape vs the other.

## Corpus stats (full run)

<!-- Fill in after running ingestion/chunk_docs.py against the full data/raw/website corpus -->

```
Total chunks generated:
Avg / min / max chars per chunk:
% of chunks from auto-generated docs:
```

## Known limitations / things to revisit

- Markdown tables (not HTML) elsewhere in the corpus aren't given special handling — treated
  as plain text. Worth checking if any prose pages use markdown tables for something
  retrieval-relevant.
- No token-based length check — using char count as a ~4-chars/token proxy. Revisit with
  `tiktoken` if exact sizing starts to matter.
- `SKIP_INHERITED_OPTIONS` is a blunt all-or-nothing exclusion — revisit if eval shows global
  flag lookups ("what does --kubeconfig do") are a real query pattern users hit.

## Deliverable

- [x] `ingestion/chunk_docs.py` written
- [x] Tested against representative samples of both document shapes (prose + auto-gen
      reference), bugs found and fixed (heading duplication, min-length filtering,
      shortcode artifacts)
- [ ] Run against the full real corpus (`data/raw/website`, 1672 files)
- [ ] Corpus stats above filled in
- [ ] Spot-check 5-10 chunks from `reference/` and 5-10 from `concepts/`/`tasks/` for quality

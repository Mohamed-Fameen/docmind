# Phase 8 — Evaluation

**Status:** written, NOT yet run — this sandbox has no network access, so `ragas`,
`langchain-ollama`, `langchain-huggingface`, and `datasets` couldn't be installed to test
against the real library APIs (same constraint hit with `langgraph` in Phase 5 and
`passlib`/`bcrypt` in Phase 6 — both of those turned out to have real, non-obvious issues
once actually run, so budget for the real possibility this does too)
**Date:** <!-- fill in -->

## Goal

Turn "it seems to work" into a number. Every quality issue found so far (the DaemonSet
fabricated citation, the missing `[1]` citation, the classifier's `clarify`-vs-off-topic
confusion) was caught by manually reading one response at a time — that doesn't scale, and
gives no way to know if a change made things better or worse overall versus just different
on the one example you happened to check.

## The four RAGAS metrics, and what each one is actually for

| Metric | Question it answers | Needs ground truth? |
|---|---|---|
| Faithfulness | Does every claim in the answer trace back to retrieved context? | No |
| Answer relevancy | Does the answer address what was actually asked? | No |
| Context precision | Of the retrieved chunks, how many were actually useful? | No |
| Context recall | Did retrieval find everything needed for a complete answer? | **Yes** |

**Faithfulness is the metric that would have caught the DaemonSet hallucinated citation
automatically** (Phase 6) — it works by extracting individual claims from the answer, then
checking each one against retrieved context for support, which is exactly the manual check
that was done by hand there. This isn't a coincidental parallel; it's the actual reason this
metric exists.

## LLM-as-judge, and its real limitation

RAGAS scores things by using an LLM to judge ("here's a claim, here's the context, is it
supported?"). Score quality is bounded by judge quality. `run_eval.py` defaults to judging
with the same local 3B model used for generation — a real, acknowledged weakness
(self-evaluation bias: a model isn't necessarily good at catching its own mistakes,
especially a small one). `JUDGE_MODEL` is a single named constant specifically so this is
easy to swap once Bedrock credentials are set up — using an independent, stronger judge to
score answers is also exactly the mechanism the planned 3B-vs-8B comparison work needs.

## Reference-free vs reference-based — why the test set is built the way it is

Faithfulness, answer relevancy, and context precision need only the question, retrieved
context, and generated answer. Context recall needs a human-written reference answer, which
is real work to produce — so `eval/test_set.py` only attaches a `ground_truth` to 2 of the 5
curated questions, and runs context_recall as a separate, smaller pass over just those,
rather than blocking the whole eval on writing reference answers for everything.

## Test set composition — real data, not just hand-picked "nice" questions

`eval/test_set.py` combines two sources deliberately:

1. **A curated set** covering distinct, already-characterized query types: a specific
   reference lookup (kubeconfig context), a broad conceptual question (StatefulSet), the
   Phase 6 multi-turn follow-up (DaemonSet), the Phase 5 adversarial fictional-feature test
   (QuantumScheduler), and an out-of-domain question (baking a cake). Two of these have a
   `ground_truth`; three deliberately don't (see code comments for why each one doesn't).
2. **Real logged queries** pulled from `data/logs/queries.jsonl` (Phase 4's query logging),
   deduplicated against the curated set, capped at 20. Hand-written eval questions tend to
   be unrealistically clean; real usage is messier and more representative of what the
   system actually faces day to day.

## What `run_eval.py` actually does

Runs every test question through the **real agent graph** (`build_agent_graph`, the same
code path `/query` uses) — not a simplified re-implementation — so eval results reflect
what the deployed system actually does, including classification, retrieval, reranking,
and the confidence-based retry loop. Every question is treated as a fresh single-turn
conversation (`history: []`); this is a known simplification for the DaemonSet test case
specifically (see `test_set.py`'s comment on it).

## How to run

```bash
uv sync   # pulls in ragas, langchain-ollama, langchain-huggingface, datasets

# make sure Qdrant + Ollama are up, same as any normal backend run
docker compose -f docker/docker-compose.yml up -d

uv run python eval/run_eval.py
```

This will take a while — every test question runs the full retrieval + generation pipeline,
*then* every row gets judged by a second LLM call (or several, since faithfulness judges
each extracted claim separately) — expect this to be noticeably slower than a single manual
`/query` call, multiplied across the whole test set.

## Results

<!-- Fill in after running -->

```
Test set size: ___
Faithfulness (avg): ___
Answer relevancy (avg): ___
Context precision (avg): ___
Context recall (avg, n=___): ___

Per-question notes — anything scoring surprisingly low or high, and whether that matches
what we already know from manual testing:
```

## Known limitations / things to revisit

- **Single-turn only** — every question runs with empty history, so the DaemonSet test case
  can't actually exercise the Phase 6 `contextualize` fix within this eval harness the way
  the real conversation did. A proper multi-turn eval would need to encode a conversation as
  a sequence, not a single question — worth building if follow-up quality becomes a focus
  area, not built now to keep this phase's scope bounded.
- **Self-judging** — using the same 3B model to generate and judge is a real, acknowledged
  weakness (see LLM-as-judge section above). Revisit once Bedrock is set up.
- **Small test set** — 5 curated + up to 20 logged questions is enough to validate the
  harness works and get a first directional read, not enough to draw strong conclusions from.
  Growing the test set over time (especially by continuing to mine real query logs) is more
  valuable than trying to hand-write a large set up front.
- **This entire phase is unverified against the real RAGAS API** — written from training-data
  knowledge of the ragas ~0.2.x API surface (specifically, that `LangchainLLMWrapper`/
  `LangchainEmbeddingsWrapper` are required rather than passing raw LangChain objects to
  `evaluate()`), with no ability to test that assumption in this sandbox. Budget real time
  for this to need at least one round of fixes once actually run — consistent with what
  happened with LangGraph (Phase 5) and passlib/bcrypt (Phase 6), both of which looked
  correct on paper and had real issues the moment they touched actual library versions.
- **Confirmed real issue #1**: importing `ragas` at all triggers
  `ragas/llms/base.py` to unconditionally import `ChatVertexAI` from `langchain_community`,
  regardless of which LLM provider is actually being used — a common but genuinely poor
  pattern (eagerly importing every optional integration at package load time instead of
  lazily importing only what's requested). `langchain-community` wasn't explicitly declared
  as a dependency (only pulled in incidentally, if at all, by something else), so this
  surfaced as a `ModuleNotFoundError`. Fixed by declaring it explicitly — genuinely
  unverified whether this fully resolves it or just gets past this specific import, since
  there could be further hidden dependencies in that same import chain.

## Deliverable

- [x] `eval/test_set.py` — curated + real-log-sourced test questions
- [x] `eval/run_eval.py` — runs real agent graph, scores with RAGAS, saves results
- [x] Test set builder logic unit-tested in isolation (dedup, ground-truth tagging)
- [ ] Full eval run against real Qdrant + Ollama — genuinely unverified, budget for fixes
- [ ] Results filled in above
